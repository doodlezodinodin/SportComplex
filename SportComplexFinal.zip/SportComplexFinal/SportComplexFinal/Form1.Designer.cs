﻿namespace SportComplexFinal
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnInstructions = new System.Windows.Forms.Button();
            this.btnClients = new System.Windows.Forms.Button();
            this.btnSchedule = new System.Windows.Forms.Button();
            this.btnCost = new System.Windows.Forms.Button();
            this.btnInsert = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panelRegistr = new System.Windows.Forms.Panel();
            this.lbPass = new System.Windows.Forms.Label();
            this.lbLogin = new System.Windows.Forms.Label();
            this.tbPass = new System.Windows.Forms.TextBox();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.lbError = new System.Windows.Forms.Label();
            this.lbError2 = new System.Windows.Forms.Label();
            this.lbError3 = new System.Windows.Forms.Label();
            this.panelClients = new System.Windows.Forms.Panel();
            this.lbCId = new System.Windows.Forms.Label();
            this.tbCId = new System.Windows.Forms.TextBox();
            this.btnICClose = new System.Windows.Forms.Button();
            this.btnICOk = new System.Windows.Forms.Button();
            this.lbICAddress = new System.Windows.Forms.Label();
            this.lbICMobile = new System.Windows.Forms.Label();
            this.lbICDate = new System.Windows.Forms.Label();
            this.lbICPat = new System.Windows.Forms.Label();
            this.lbICName = new System.Windows.Forms.Label();
            this.lbICSurname = new System.Windows.Forms.Label();
            this.tbICAddress = new System.Windows.Forms.TextBox();
            this.tbICMobile = new System.Windows.Forms.TextBox();
            this.tbICDate = new System.Windows.Forms.TextBox();
            this.tbICPat = new System.Windows.Forms.TextBox();
            this.tbICName = new System.Windows.Forms.TextBox();
            this.tbICSurname = new System.Windows.Forms.TextBox();
            this.panelSchedule = new System.Windows.Forms.Panel();
            this.lbSId = new System.Windows.Forms.Label();
            this.tbSId = new System.Windows.Forms.TextBox();
            this.btnISClose = new System.Windows.Forms.Button();
            this.btnISOk = new System.Windows.Forms.Button();
            this.lbISTimeFinish = new System.Windows.Forms.Label();
            this.lbISTimeStart = new System.Windows.Forms.Label();
            this.lbISDate = new System.Windows.Forms.Label();
            this.lbISId = new System.Windows.Forms.Label();
            this.tbISFinish = new System.Windows.Forms.TextBox();
            this.tbISTimeStart = new System.Windows.Forms.TextBox();
            this.tbISDate = new System.Windows.Forms.TextBox();
            this.tbISId = new System.Windows.Forms.TextBox();
            this.panelInstructions = new System.Windows.Forms.Panel();
            this.lbIId = new System.Windows.Forms.Label();
            this.tbIId = new System.Windows.Forms.TextBox();
            this.btnIIClose = new System.Windows.Forms.Button();
            this.btnIIOk = new System.Windows.Forms.Button();
            this.lbIIPat = new System.Windows.Forms.Label();
            this.lbIIName = new System.Windows.Forms.Label();
            this.lbIISurname = new System.Windows.Forms.Label();
            this.tbIIPat = new System.Windows.Forms.TextBox();
            this.tbIIName = new System.Windows.Forms.TextBox();
            this.tbIISurname = new System.Windows.Forms.TextBox();
            this.panelCost = new System.Windows.Forms.Panel();
            this.lbCostId = new System.Windows.Forms.Label();
            this.tbCostId = new System.Windows.Forms.TextBox();
            this.btnICostOk = new System.Windows.Forms.Button();
            this.btnICostClose = new System.Windows.Forms.Button();
            this.lbICostCount = new System.Windows.Forms.Label();
            this.lbICostCost = new System.Windows.Forms.Label();
            this.lbICostName = new System.Windows.Forms.Label();
            this.tpICostCount = new System.Windows.Forms.TextBox();
            this.tpICostCost = new System.Windows.Forms.TextBox();
            this.tpICostName = new System.Windows.Forms.TextBox();
            this.lbPanelError = new System.Windows.Forms.Label();
            this.btnOkClose = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.настройкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сменитьПарольToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.расположениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelLP = new System.Windows.Forms.Panel();
            this.btnLPClose = new System.Windows.Forms.Button();
            this.lbLPError = new System.Windows.Forms.Label();
            this.btnLPOk = new System.Windows.Forms.Button();
            this.lbNewPass = new System.Windows.Forms.Label();
            this.lbNewLogin = new System.Windows.Forms.Label();
            this.lbOldPass = new System.Windows.Forms.Label();
            this.lbOldLogin = new System.Windows.Forms.Label();
            this.tbNewPass = new System.Windows.Forms.TextBox();
            this.tbNewLogin = new System.Windows.Forms.TextBox();
            this.tbOldPass = new System.Windows.Forms.TextBox();
            this.tbOldLogin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelOne = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelRegistr.SuspendLayout();
            this.panelClients.SuspendLayout();
            this.panelSchedule.SuspendLayout();
            this.panelInstructions.SuspendLayout();
            this.panelCost.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panelLP.SuspendLayout();
            this.panelOne.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(638, 401);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(101, 44);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Завершить";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnInstructions
            // 
            this.btnInstructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnInstructions.Location = new System.Drawing.Point(12, 98);
            this.btnInstructions.Name = "btnInstructions";
            this.btnInstructions.Size = new System.Drawing.Size(101, 45);
            this.btnInstructions.TabIndex = 2;
            this.btnInstructions.Text = "Инструкторы";
            this.btnInstructions.UseVisualStyleBackColor = true;
            this.btnInstructions.Click += new System.EventHandler(this.btnInstructions_Click);
            // 
            // btnClients
            // 
            this.btnClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnClients.Location = new System.Drawing.Point(12, 149);
            this.btnClients.Name = "btnClients";
            this.btnClients.Size = new System.Drawing.Size(101, 45);
            this.btnClients.TabIndex = 3;
            this.btnClients.Text = "Клиенты";
            this.btnClients.UseVisualStyleBackColor = true;
            this.btnClients.Click += new System.EventHandler(this.btnClients_Click);
            // 
            // btnSchedule
            // 
            this.btnSchedule.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSchedule.Location = new System.Drawing.Point(12, 200);
            this.btnSchedule.Name = "btnSchedule";
            this.btnSchedule.Size = new System.Drawing.Size(101, 45);
            this.btnSchedule.TabIndex = 4;
            this.btnSchedule.Text = "Расписание";
            this.btnSchedule.UseVisualStyleBackColor = true;
            this.btnSchedule.Click += new System.EventHandler(this.btnSchedule_Click);
            // 
            // btnCost
            // 
            this.btnCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnCost.Location = new System.Drawing.Point(12, 251);
            this.btnCost.Name = "btnCost";
            this.btnCost.Size = new System.Drawing.Size(101, 45);
            this.btnCost.TabIndex = 5;
            this.btnCost.Text = "Стоимость";
            this.btnCost.UseVisualStyleBackColor = true;
            this.btnCost.Click += new System.EventHandler(this.btnCost_Click);
            // 
            // btnInsert
            // 
            this.btnInsert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnInsert.Location = new System.Drawing.Point(638, 98);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(101, 45);
            this.btnInsert.TabIndex = 6;
            this.btnInsert.Text = "Добавить";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Visible = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(132, 98);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(489, 199);
            this.listBox.TabIndex = 8;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUpdate.Location = new System.Drawing.Point(638, 149);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(101, 45);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "Изменить";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Visible = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnDelete.Location = new System.Drawing.Point(638, 201);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(101, 45);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Visible = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // panelRegistr
            // 
            this.panelRegistr.BackColor = System.Drawing.Color.Gainsboro;
            this.panelRegistr.Controls.Add(this.lbPass);
            this.panelRegistr.Controls.Add(this.lbLogin);
            this.panelRegistr.Controls.Add(this.tbPass);
            this.panelRegistr.Controls.Add(this.tbLogin);
            this.panelRegistr.Location = new System.Drawing.Point(328, -2);
            this.panelRegistr.Name = "panelRegistr";
            this.panelRegistr.Size = new System.Drawing.Size(332, 26);
            this.panelRegistr.TabIndex = 12;
            // 
            // lbPass
            // 
            this.lbPass.AutoSize = true;
            this.lbPass.Location = new System.Drawing.Point(177, 10);
            this.lbPass.Name = "lbPass";
            this.lbPass.Size = new System.Drawing.Size(45, 13);
            this.lbPass.TabIndex = 3;
            this.lbPass.Text = "Пароль";
            // 
            // lbLogin
            // 
            this.lbLogin.AutoSize = true;
            this.lbLogin.Location = new System.Drawing.Point(7, 10);
            this.lbLogin.Name = "lbLogin";
            this.lbLogin.Size = new System.Drawing.Size(38, 13);
            this.lbLogin.TabIndex = 2;
            this.lbLogin.Text = "Логин";
            // 
            // tbPass
            // 
            this.tbPass.Location = new System.Drawing.Point(224, 3);
            this.tbPass.Name = "tbPass";
            this.tbPass.Size = new System.Drawing.Size(100, 20);
            this.tbPass.TabIndex = 1;
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(46, 3);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(100, 20);
            this.tbLogin.TabIndex = 0;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(664, 0);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 13;
            this.btnOk.Text = "Войти";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // lbError
            // 
            this.lbError.AutoSize = true;
            this.lbError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbError.ForeColor = System.Drawing.Color.Red;
            this.lbError.Location = new System.Drawing.Point(24, 37);
            this.lbError.Name = "lbError";
            this.lbError.Size = new System.Drawing.Size(272, 17);
            this.lbError.TabIndex = 14;
            this.lbError.Text = "Вы находитесь в режиме пользователя*";
            // 
            // lbError2
            // 
            this.lbError2.AutoSize = true;
            this.lbError2.Location = new System.Drawing.Point(24, 55);
            this.lbError2.Name = "lbError2";
            this.lbError2.Size = new System.Drawing.Size(225, 13);
            this.lbError2.TabIndex = 15;
            this.lbError2.Text = "(вы можете только просматривать файлы)";
            // 
            // lbError3
            // 
            this.lbError3.AutoSize = true;
            this.lbError3.ForeColor = System.Drawing.Color.Red;
            this.lbError3.Location = new System.Drawing.Point(455, 27);
            this.lbError3.Name = "lbError3";
            this.lbError3.Size = new System.Drawing.Size(130, 13);
            this.lbError3.TabIndex = 16;
            this.lbError3.Text = "не все поля заполнены*";
            this.lbError3.Visible = false;
            // 
            // panelClients
            // 
            this.panelClients.Controls.Add(this.lbCId);
            this.panelClients.Controls.Add(this.tbCId);
            this.panelClients.Controls.Add(this.btnICClose);
            this.panelClients.Controls.Add(this.btnICOk);
            this.panelClients.Controls.Add(this.lbICAddress);
            this.panelClients.Controls.Add(this.lbICMobile);
            this.panelClients.Controls.Add(this.lbICDate);
            this.panelClients.Controls.Add(this.lbICPat);
            this.panelClients.Controls.Add(this.lbICName);
            this.panelClients.Controls.Add(this.lbICSurname);
            this.panelClients.Controls.Add(this.tbICAddress);
            this.panelClients.Controls.Add(this.tbICMobile);
            this.panelClients.Controls.Add(this.tbICDate);
            this.panelClients.Controls.Add(this.tbICPat);
            this.panelClients.Controls.Add(this.tbICName);
            this.panelClients.Controls.Add(this.tbICSurname);
            this.panelClients.Location = new System.Drawing.Point(56, 354);
            this.panelClients.Name = "panelClients";
            this.panelClients.Size = new System.Drawing.Size(670, 72);
            this.panelClients.TabIndex = 18;
            this.panelClients.Visible = false;
            // 
            // lbCId
            // 
            this.lbCId.AutoSize = true;
            this.lbCId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbCId.Location = new System.Drawing.Point(3, 2);
            this.lbCId.Name = "lbCId";
            this.lbCId.Size = new System.Drawing.Size(26, 13);
            this.lbCId.TabIndex = 19;
            this.lbCId.Text = "Код";
            this.lbCId.Visible = false;
            // 
            // tbCId
            // 
            this.tbCId.Location = new System.Drawing.Point(3, 18);
            this.tbCId.Name = "tbCId";
            this.tbCId.Size = new System.Drawing.Size(49, 20);
            this.tbCId.TabIndex = 18;
            this.tbCId.Visible = false;
            // 
            // btnICClose
            // 
            this.btnICClose.Location = new System.Drawing.Point(590, 44);
            this.btnICClose.Name = "btnICClose";
            this.btnICClose.Size = new System.Drawing.Size(75, 23);
            this.btnICClose.TabIndex = 14;
            this.btnICClose.Text = "Отмена";
            this.btnICClose.UseVisualStyleBackColor = true;
            this.btnICClose.Click += new System.EventHandler(this.btnICClose_Click);
            // 
            // btnICOk
            // 
            this.btnICOk.Location = new System.Drawing.Point(509, 44);
            this.btnICOk.Name = "btnICOk";
            this.btnICOk.Size = new System.Drawing.Size(75, 23);
            this.btnICOk.TabIndex = 12;
            this.btnICOk.Text = "Ок";
            this.btnICOk.UseVisualStyleBackColor = true;
            this.btnICOk.Click += new System.EventHandler(this.btnICOk_Click);
            // 
            // lbICAddress
            // 
            this.lbICAddress.AutoSize = true;
            this.lbICAddress.Location = new System.Drawing.Point(566, 2);
            this.lbICAddress.Name = "lbICAddress";
            this.lbICAddress.Size = new System.Drawing.Size(38, 13);
            this.lbICAddress.TabIndex = 11;
            this.lbICAddress.Text = "Адрес";
            // 
            // lbICMobile
            // 
            this.lbICMobile.AutoSize = true;
            this.lbICMobile.Location = new System.Drawing.Point(467, 2);
            this.lbICMobile.Name = "lbICMobile";
            this.lbICMobile.Size = new System.Drawing.Size(52, 13);
            this.lbICMobile.TabIndex = 10;
            this.lbICMobile.Text = "Телефон";
            // 
            // lbICDate
            // 
            this.lbICDate.AutoSize = true;
            this.lbICDate.Location = new System.Drawing.Point(362, 2);
            this.lbICDate.Name = "lbICDate";
            this.lbICDate.Size = new System.Drawing.Size(86, 13);
            this.lbICDate.TabIndex = 9;
            this.lbICDate.Text = "Дата рождения";
            // 
            // lbICPat
            // 
            this.lbICPat.AutoSize = true;
            this.lbICPat.Location = new System.Drawing.Point(260, 2);
            this.lbICPat.Name = "lbICPat";
            this.lbICPat.Size = new System.Drawing.Size(54, 13);
            this.lbICPat.TabIndex = 8;
            this.lbICPat.Text = "Отчество";
            // 
            // lbICName
            // 
            this.lbICName.AutoSize = true;
            this.lbICName.Location = new System.Drawing.Point(158, 2);
            this.lbICName.Name = "lbICName";
            this.lbICName.Size = new System.Drawing.Size(29, 13);
            this.lbICName.TabIndex = 7;
            this.lbICName.Text = "Имя";
            // 
            // lbICSurname
            // 
            this.lbICSurname.AutoSize = true;
            this.lbICSurname.Location = new System.Drawing.Point(58, 2);
            this.lbICSurname.Name = "lbICSurname";
            this.lbICSurname.Size = new System.Drawing.Size(56, 13);
            this.lbICSurname.TabIndex = 6;
            this.lbICSurname.Text = "Фамилия";
            // 
            // tbICAddress
            // 
            this.tbICAddress.Location = new System.Drawing.Point(569, 18);
            this.tbICAddress.Name = "tbICAddress";
            this.tbICAddress.Size = new System.Drawing.Size(96, 20);
            this.tbICAddress.TabIndex = 5;
            // 
            // tbICMobile
            // 
            this.tbICMobile.Location = new System.Drawing.Point(467, 18);
            this.tbICMobile.Name = "tbICMobile";
            this.tbICMobile.Size = new System.Drawing.Size(96, 20);
            this.tbICMobile.TabIndex = 4;
            // 
            // tbICDate
            // 
            this.tbICDate.Location = new System.Drawing.Point(365, 18);
            this.tbICDate.Name = "tbICDate";
            this.tbICDate.Size = new System.Drawing.Size(96, 20);
            this.tbICDate.TabIndex = 3;
            // 
            // tbICPat
            // 
            this.tbICPat.Location = new System.Drawing.Point(263, 18);
            this.tbICPat.Name = "tbICPat";
            this.tbICPat.Size = new System.Drawing.Size(96, 20);
            this.tbICPat.TabIndex = 2;
            // 
            // tbICName
            // 
            this.tbICName.Location = new System.Drawing.Point(161, 18);
            this.tbICName.Name = "tbICName";
            this.tbICName.Size = new System.Drawing.Size(96, 20);
            this.tbICName.TabIndex = 1;
            // 
            // tbICSurname
            // 
            this.tbICSurname.Location = new System.Drawing.Point(58, 18);
            this.tbICSurname.Name = "tbICSurname";
            this.tbICSurname.Size = new System.Drawing.Size(97, 20);
            this.tbICSurname.TabIndex = 0;
            // 
            // panelSchedule
            // 
            this.panelSchedule.Controls.Add(this.lbSId);
            this.panelSchedule.Controls.Add(this.tbSId);
            this.panelSchedule.Controls.Add(this.btnISClose);
            this.panelSchedule.Controls.Add(this.btnISOk);
            this.panelSchedule.Controls.Add(this.lbISTimeFinish);
            this.panelSchedule.Controls.Add(this.lbISTimeStart);
            this.panelSchedule.Controls.Add(this.lbISDate);
            this.panelSchedule.Controls.Add(this.lbISId);
            this.panelSchedule.Controls.Add(this.tbISFinish);
            this.panelSchedule.Controls.Add(this.tbISTimeStart);
            this.panelSchedule.Controls.Add(this.tbISDate);
            this.panelSchedule.Controls.Add(this.tbISId);
            this.panelSchedule.Location = new System.Drawing.Point(112, 334);
            this.panelSchedule.Name = "panelSchedule";
            this.panelSchedule.Size = new System.Drawing.Size(528, 96);
            this.panelSchedule.TabIndex = 21;
            this.panelSchedule.Visible = false;
            // 
            // lbSId
            // 
            this.lbSId.AutoSize = true;
            this.lbSId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbSId.Location = new System.Drawing.Point(4, 18);
            this.lbSId.Name = "lbSId";
            this.lbSId.Size = new System.Drawing.Size(26, 13);
            this.lbSId.TabIndex = 20;
            this.lbSId.Text = "Код";
            this.lbSId.Visible = false;
            // 
            // tbSId
            // 
            this.tbSId.Location = new System.Drawing.Point(4, 34);
            this.tbSId.Name = "tbSId";
            this.tbSId.Size = new System.Drawing.Size(49, 20);
            this.tbSId.TabIndex = 19;
            this.tbSId.Visible = false;
            // 
            // btnISClose
            // 
            this.btnISClose.Location = new System.Drawing.Point(450, 60);
            this.btnISClose.Name = "btnISClose";
            this.btnISClose.Size = new System.Drawing.Size(75, 23);
            this.btnISClose.TabIndex = 18;
            this.btnISClose.Text = "Отмена";
            this.btnISClose.UseVisualStyleBackColor = true;
            this.btnISClose.Click += new System.EventHandler(this.btnISClose_Click);
            // 
            // btnISOk
            // 
            this.btnISOk.Location = new System.Drawing.Point(366, 60);
            this.btnISOk.Name = "btnISOk";
            this.btnISOk.Size = new System.Drawing.Size(75, 23);
            this.btnISOk.TabIndex = 17;
            this.btnISOk.Text = "Ок";
            this.btnISOk.UseVisualStyleBackColor = true;
            this.btnISOk.Click += new System.EventHandler(this.btnISOk_Click);
            // 
            // lbISTimeFinish
            // 
            this.lbISTimeFinish.AutoSize = true;
            this.lbISTimeFinish.Location = new System.Drawing.Point(413, 18);
            this.lbISTimeFinish.Name = "lbISTimeFinish";
            this.lbISTimeFinish.Size = new System.Drawing.Size(96, 13);
            this.lbISTimeFinish.TabIndex = 16;
            this.lbISTimeFinish.Text = "Время окончания";
            // 
            // lbISTimeStart
            // 
            this.lbISTimeStart.AutoSize = true;
            this.lbISTimeStart.Location = new System.Drawing.Point(295, 18);
            this.lbISTimeStart.Name = "lbISTimeStart";
            this.lbISTimeStart.Size = new System.Drawing.Size(78, 13);
            this.lbISTimeStart.TabIndex = 15;
            this.lbISTimeStart.Text = "Время начала";
            // 
            // lbISDate
            // 
            this.lbISDate.AutoSize = true;
            this.lbISDate.Location = new System.Drawing.Point(177, 18);
            this.lbISDate.Name = "lbISDate";
            this.lbISDate.Size = new System.Drawing.Size(96, 13);
            this.lbISDate.TabIndex = 14;
            this.lbISDate.Text = "Дата проведения";
            // 
            // lbISId
            // 
            this.lbISId.AutoSize = true;
            this.lbISId.Location = new System.Drawing.Point(56, 18);
            this.lbISId.Name = "lbISId";
            this.lbISId.Size = new System.Drawing.Size(65, 13);
            this.lbISId.TabIndex = 13;
            this.lbISId.Text = "Код группы";
            // 
            // tbISFinish
            // 
            this.tbISFinish.Location = new System.Drawing.Point(413, 34);
            this.tbISFinish.Name = "tbISFinish";
            this.tbISFinish.Size = new System.Drawing.Size(112, 20);
            this.tbISFinish.TabIndex = 3;
            // 
            // tbISTimeStart
            // 
            this.tbISTimeStart.Location = new System.Drawing.Point(295, 34);
            this.tbISTimeStart.Name = "tbISTimeStart";
            this.tbISTimeStart.Size = new System.Drawing.Size(112, 20);
            this.tbISTimeStart.TabIndex = 2;
            // 
            // tbISDate
            // 
            this.tbISDate.Location = new System.Drawing.Point(177, 34);
            this.tbISDate.Name = "tbISDate";
            this.tbISDate.Size = new System.Drawing.Size(112, 20);
            this.tbISDate.TabIndex = 1;
            // 
            // tbISId
            // 
            this.tbISId.Location = new System.Drawing.Point(59, 34);
            this.tbISId.Name = "tbISId";
            this.tbISId.Size = new System.Drawing.Size(112, 20);
            this.tbISId.TabIndex = 0;
            // 
            // panelInstructions
            // 
            this.panelInstructions.Controls.Add(this.lbIId);
            this.panelInstructions.Controls.Add(this.tbIId);
            this.panelInstructions.Controls.Add(this.btnIIClose);
            this.panelInstructions.Controls.Add(this.btnIIOk);
            this.panelInstructions.Controls.Add(this.lbIIPat);
            this.panelInstructions.Controls.Add(this.lbIIName);
            this.panelInstructions.Controls.Add(this.lbIISurname);
            this.panelInstructions.Controls.Add(this.tbIIPat);
            this.panelInstructions.Controls.Add(this.tbIIName);
            this.panelInstructions.Controls.Add(this.tbIISurname);
            this.panelInstructions.Location = new System.Drawing.Point(132, 320);
            this.panelInstructions.Name = "panelInstructions";
            this.panelInstructions.Size = new System.Drawing.Size(475, 72);
            this.panelInstructions.TabIndex = 24;
            this.panelInstructions.Visible = false;
            // 
            // lbIId
            // 
            this.lbIId.AutoSize = true;
            this.lbIId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbIId.Location = new System.Drawing.Point(3, 2);
            this.lbIId.Name = "lbIId";
            this.lbIId.Size = new System.Drawing.Size(26, 13);
            this.lbIId.TabIndex = 17;
            this.lbIId.Text = "Код";
            this.lbIId.Visible = false;
            // 
            // tbIId
            // 
            this.tbIId.Location = new System.Drawing.Point(3, 18);
            this.tbIId.Name = "tbIId";
            this.tbIId.Size = new System.Drawing.Size(49, 20);
            this.tbIId.TabIndex = 16;
            this.tbIId.Visible = false;
            // 
            // btnIIClose
            // 
            this.btnIIClose.Location = new System.Drawing.Point(396, 44);
            this.btnIIClose.Name = "btnIIClose";
            this.btnIIClose.Size = new System.Drawing.Size(75, 23);
            this.btnIIClose.TabIndex = 15;
            this.btnIIClose.Text = "Отмена";
            this.btnIIClose.UseVisualStyleBackColor = true;
            this.btnIIClose.Click += new System.EventHandler(this.btnIIClose_Click);
            // 
            // btnIIOk
            // 
            this.btnIIOk.Location = new System.Drawing.Point(315, 44);
            this.btnIIOk.Name = "btnIIOk";
            this.btnIIOk.Size = new System.Drawing.Size(75, 23);
            this.btnIIOk.TabIndex = 6;
            this.btnIIOk.Text = "Ок";
            this.btnIIOk.UseVisualStyleBackColor = true;
            this.btnIIOk.Click += new System.EventHandler(this.btnIIOk_Click);
            // 
            // lbIIPat
            // 
            this.lbIIPat.AutoSize = true;
            this.lbIIPat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbIIPat.Location = new System.Drawing.Point(339, 2);
            this.lbIIPat.Name = "lbIIPat";
            this.lbIIPat.Size = new System.Drawing.Size(54, 13);
            this.lbIIPat.TabIndex = 5;
            this.lbIIPat.Text = "Отчество";
            // 
            // lbIIName
            // 
            this.lbIIName.AutoSize = true;
            this.lbIIName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbIIName.Location = new System.Drawing.Point(197, 2);
            this.lbIIName.Name = "lbIIName";
            this.lbIIName.Size = new System.Drawing.Size(29, 13);
            this.lbIIName.TabIndex = 4;
            this.lbIIName.Text = "Имя";
            // 
            // lbIISurname
            // 
            this.lbIISurname.AutoSize = true;
            this.lbIISurname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbIISurname.Location = new System.Drawing.Point(55, 2);
            this.lbIISurname.Name = "lbIISurname";
            this.lbIISurname.Size = new System.Drawing.Size(56, 13);
            this.lbIISurname.TabIndex = 3;
            this.lbIISurname.Text = "Фамилия";
            // 
            // tbIIPat
            // 
            this.tbIIPat.Location = new System.Drawing.Point(342, 18);
            this.tbIIPat.Name = "tbIIPat";
            this.tbIIPat.Size = new System.Drawing.Size(129, 20);
            this.tbIIPat.TabIndex = 2;
            // 
            // tbIIName
            // 
            this.tbIIName.Location = new System.Drawing.Point(200, 18);
            this.tbIIName.Name = "tbIIName";
            this.tbIIName.Size = new System.Drawing.Size(136, 20);
            this.tbIIName.TabIndex = 1;
            // 
            // tbIISurname
            // 
            this.tbIISurname.Location = new System.Drawing.Point(58, 18);
            this.tbIISurname.Name = "tbIISurname";
            this.tbIISurname.Size = new System.Drawing.Size(136, 20);
            this.tbIISurname.TabIndex = 0;
            // 
            // panelCost
            // 
            this.panelCost.Controls.Add(this.lbCostId);
            this.panelCost.Controls.Add(this.tbCostId);
            this.panelCost.Controls.Add(this.btnICostOk);
            this.panelCost.Controls.Add(this.btnICostClose);
            this.panelCost.Controls.Add(this.lbICostCount);
            this.panelCost.Controls.Add(this.lbICostCost);
            this.panelCost.Controls.Add(this.lbICostName);
            this.panelCost.Controls.Add(this.tpICostCount);
            this.panelCost.Controls.Add(this.tpICostCost);
            this.panelCost.Controls.Add(this.tpICostName);
            this.panelCost.Location = new System.Drawing.Point(154, 331);
            this.panelCost.Name = "panelCost";
            this.panelCost.Size = new System.Drawing.Size(434, 111);
            this.panelCost.TabIndex = 22;
            this.panelCost.Visible = false;
            // 
            // lbCostId
            // 
            this.lbCostId.AutoSize = true;
            this.lbCostId.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbCostId.Location = new System.Drawing.Point(5, 23);
            this.lbCostId.Name = "lbCostId";
            this.lbCostId.Size = new System.Drawing.Size(26, 13);
            this.lbCostId.TabIndex = 19;
            this.lbCostId.Text = "Код";
            this.lbCostId.Visible = false;
            // 
            // tbCostId
            // 
            this.tbCostId.Location = new System.Drawing.Point(5, 39);
            this.tbCostId.Name = "tbCostId";
            this.tbCostId.Size = new System.Drawing.Size(49, 20);
            this.tbCostId.TabIndex = 18;
            this.tbCostId.Visible = false;
            // 
            // btnICostOk
            // 
            this.btnICostOk.Location = new System.Drawing.Point(275, 65);
            this.btnICostOk.Name = "btnICostOk";
            this.btnICostOk.Size = new System.Drawing.Size(75, 23);
            this.btnICostOk.TabIndex = 14;
            this.btnICostOk.Text = "Ок";
            this.btnICostOk.UseVisualStyleBackColor = true;
            this.btnICostOk.Click += new System.EventHandler(this.btnICostOk_Click);
            // 
            // btnICostClose
            // 
            this.btnICostClose.Location = new System.Drawing.Point(356, 65);
            this.btnICostClose.Name = "btnICostClose";
            this.btnICostClose.Size = new System.Drawing.Size(75, 23);
            this.btnICostClose.TabIndex = 13;
            this.btnICostClose.Text = "Отмена";
            this.btnICostClose.UseVisualStyleBackColor = true;
            this.btnICostClose.Click += new System.EventHandler(this.btnICostClose_Click);
            // 
            // lbICostCount
            // 
            this.lbICostCount.AutoSize = true;
            this.lbICostCount.Location = new System.Drawing.Point(308, 23);
            this.lbICostCount.Name = "lbICostCount";
            this.lbICostCount.Size = new System.Drawing.Size(103, 13);
            this.lbICostCount.TabIndex = 5;
            this.lbICostCount.Text = "Кол-во тренировок";
            // 
            // lbICostCost
            // 
            this.lbICostCost.AutoSize = true;
            this.lbICostCost.Location = new System.Drawing.Point(183, 23);
            this.lbICostCost.Name = "lbICostCost";
            this.lbICostCost.Size = new System.Drawing.Size(62, 13);
            this.lbICostCost.TabIndex = 4;
            this.lbICostCost.Text = "Стоимость";
            // 
            // lbICostName
            // 
            this.lbICostName.AutoSize = true;
            this.lbICostName.Location = new System.Drawing.Point(57, 23);
            this.lbICostName.Name = "lbICostName";
            this.lbICostName.Size = new System.Drawing.Size(101, 13);
            this.lbICostName.TabIndex = 3;
            this.lbICostName.Text = "Название занятия";
            // 
            // tpICostCount
            // 
            this.tpICostCount.Location = new System.Drawing.Point(311, 39);
            this.tpICostCount.Name = "tpICostCount";
            this.tpICostCount.Size = new System.Drawing.Size(120, 20);
            this.tpICostCount.TabIndex = 2;
            // 
            // tpICostCost
            // 
            this.tpICostCost.Location = new System.Drawing.Point(186, 39);
            this.tpICostCost.Name = "tpICostCost";
            this.tpICostCost.Size = new System.Drawing.Size(120, 20);
            this.tpICostCost.TabIndex = 1;
            // 
            // tpICostName
            // 
            this.tpICostName.Location = new System.Drawing.Point(60, 39);
            this.tpICostName.Name = "tpICostName";
            this.tpICostName.Size = new System.Drawing.Size(120, 20);
            this.tpICostName.TabIndex = 0;
            // 
            // lbPanelError
            // 
            this.lbPanelError.AutoSize = true;
            this.lbPanelError.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbPanelError.ForeColor = System.Drawing.Color.Red;
            this.lbPanelError.Location = new System.Drawing.Point(110, 300);
            this.lbPanelError.Name = "lbPanelError";
            this.lbPanelError.Size = new System.Drawing.Size(170, 17);
            this.lbPanelError.TabIndex = 25;
            this.lbPanelError.Text = "Не все поля заполнены*";
            this.lbPanelError.Visible = false;
            // 
            // btnOkClose
            // 
            this.btnOkClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnOkClose.Location = new System.Drawing.Point(638, 252);
            this.btnOkClose.Name = "btnOkClose";
            this.btnOkClose.Size = new System.Drawing.Size(101, 44);
            this.btnOkClose.TabIndex = 26;
            this.btnOkClose.Text = "Выйти";
            this.btnOkClose.UseVisualStyleBackColor = true;
            this.btnOkClose.Visible = false;
            this.btnOkClose.Click += new System.EventHandler(this.btnOkClose_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.настройкиToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(750, 24);
            this.menuStrip1.TabIndex = 27;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // настройкиToolStripMenuItem
            // 
            this.настройкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem,
            this.расположениеToolStripMenuItem,
            this.сменитьПарольToolStripMenuItem});
            this.настройкиToolStripMenuItem.Name = "настройкиToolStripMenuItem";
            this.настройкиToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.настройкиToolStripMenuItem.Text = "Настройки";
            // 
            // сменитьПарольToolStripMenuItem
            // 
            this.сменитьПарольToolStripMenuItem.Name = "сменитьПарольToolStripMenuItem";
            this.сменитьПарольToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.сменитьПарольToolStripMenuItem.Text = "Сменить пароль";
            this.сменитьПарольToolStripMenuItem.Click += new System.EventHandler(this.сменитьПарольToolStripMenuItem_Click);
            // 
            // расположениеToolStripMenuItem
            // 
            this.расположениеToolStripMenuItem.Name = "расположениеToolStripMenuItem";
            this.расположениеToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.расположениеToolStripMenuItem.Text = "Сменить расположение базы данных";
            this.расположениеToolStripMenuItem.Click += new System.EventHandler(this.расположениеToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // panelLP
            // 
            this.panelLP.Controls.Add(this.btnLPClose);
            this.panelLP.Controls.Add(this.lbLPError);
            this.panelLP.Controls.Add(this.btnLPOk);
            this.panelLP.Controls.Add(this.lbNewPass);
            this.panelLP.Controls.Add(this.lbNewLogin);
            this.panelLP.Controls.Add(this.lbOldPass);
            this.panelLP.Controls.Add(this.lbOldLogin);
            this.panelLP.Controls.Add(this.tbNewPass);
            this.panelLP.Controls.Add(this.tbNewLogin);
            this.panelLP.Controls.Add(this.tbOldPass);
            this.panelLP.Controls.Add(this.tbOldLogin);
            this.panelLP.Location = new System.Drawing.Point(241, 82);
            this.panelLP.Name = "panelLP";
            this.panelLP.Size = new System.Drawing.Size(254, 193);
            this.panelLP.TabIndex = 28;
            this.panelLP.Visible = false;
            // 
            // btnLPClose
            // 
            this.btnLPClose.Location = new System.Drawing.Point(133, 140);
            this.btnLPClose.Name = "btnLPClose";
            this.btnLPClose.Size = new System.Drawing.Size(75, 23);
            this.btnLPClose.TabIndex = 10;
            this.btnLPClose.Text = "Отмена";
            this.btnLPClose.UseVisualStyleBackColor = true;
            this.btnLPClose.Click += new System.EventHandler(this.btnLPClose_Click);
            // 
            // lbLPError
            // 
            this.lbLPError.AutoSize = true;
            this.lbLPError.Location = new System.Drawing.Point(62, 172);
            this.lbLPError.Name = "lbLPError";
            this.lbLPError.Size = new System.Drawing.Size(35, 13);
            this.lbLPError.TabIndex = 9;
            this.lbLPError.Text = "label1";
            this.lbLPError.Visible = false;
            // 
            // btnLPOk
            // 
            this.btnLPOk.Location = new System.Drawing.Point(57, 140);
            this.btnLPOk.Name = "btnLPOk";
            this.btnLPOk.Size = new System.Drawing.Size(75, 23);
            this.btnLPOk.TabIndex = 8;
            this.btnLPOk.Text = "Сменить";
            this.btnLPOk.UseVisualStyleBackColor = true;
            this.btnLPOk.Click += new System.EventHandler(this.btnLPOk_Click);
            // 
            // lbNewPass
            // 
            this.lbNewPass.AutoSize = true;
            this.lbNewPass.Location = new System.Drawing.Point(137, 85);
            this.lbNewPass.Name = "lbNewPass";
            this.lbNewPass.Size = new System.Drawing.Size(80, 13);
            this.lbNewPass.TabIndex = 7;
            this.lbNewPass.Text = "Новый пароль";
            // 
            // lbNewLogin
            // 
            this.lbNewLogin.AutoSize = true;
            this.lbNewLogin.Location = new System.Drawing.Point(20, 85);
            this.lbNewLogin.Name = "lbNewLogin";
            this.lbNewLogin.Size = new System.Drawing.Size(73, 13);
            this.lbNewLogin.TabIndex = 6;
            this.lbNewLogin.Text = "Новый логин";
            // 
            // lbOldPass
            // 
            this.lbOldPass.AutoSize = true;
            this.lbOldPass.Location = new System.Drawing.Point(137, 20);
            this.lbOldPass.Name = "lbOldPass";
            this.lbOldPass.Size = new System.Drawing.Size(84, 13);
            this.lbOldPass.TabIndex = 5;
            this.lbOldPass.Text = "Старый пароль";
            // 
            // lbOldLogin
            // 
            this.lbOldLogin.AutoSize = true;
            this.lbOldLogin.Location = new System.Drawing.Point(20, 18);
            this.lbOldLogin.Name = "lbOldLogin";
            this.lbOldLogin.Size = new System.Drawing.Size(77, 13);
            this.lbOldLogin.TabIndex = 4;
            this.lbOldLogin.Text = "Старый логин";
            // 
            // tbNewPass
            // 
            this.tbNewPass.Location = new System.Drawing.Point(140, 101);
            this.tbNewPass.Name = "tbNewPass";
            this.tbNewPass.Size = new System.Drawing.Size(100, 20);
            this.tbNewPass.TabIndex = 3;
            // 
            // tbNewLogin
            // 
            this.tbNewLogin.Location = new System.Drawing.Point(23, 101);
            this.tbNewLogin.Name = "tbNewLogin";
            this.tbNewLogin.Size = new System.Drawing.Size(100, 20);
            this.tbNewLogin.TabIndex = 2;
            // 
            // tbOldPass
            // 
            this.tbOldPass.Location = new System.Drawing.Point(140, 36);
            this.tbOldPass.Name = "tbOldPass";
            this.tbOldPass.Size = new System.Drawing.Size(100, 20);
            this.tbOldPass.TabIndex = 1;
            // 
            // tbOldLogin
            // 
            this.tbOldLogin.Location = new System.Drawing.Point(23, 36);
            this.tbOldLogin.Name = "tbOldLogin";
            this.tbOldLogin.Size = new System.Drawing.Size(100, 20);
            this.tbOldLogin.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 417);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // panelOne
            // 
            this.panelOne.Controls.Add(this.button2);
            this.panelOne.Controls.Add(this.button1);
            this.panelOne.Controls.Add(this.label2);
            this.panelOne.Controls.Add(this.textBox1);
            this.panelOne.Location = new System.Drawing.Point(174, 124);
            this.panelOne.Name = "panelOne";
            this.panelOne.Size = new System.Drawing.Size(433, 109);
            this.panelOne.TabIndex = 30;
            this.panelOne.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(336, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Отмена";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(255, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Ок";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Расположение базы данных: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(22, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(389, 20);
            this.textBox1.TabIndex = 0;
            // 
            // открытьСтандартнуюБазуДанныхToolStripMenuItem
            // 
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem.Name = "открытьСтандартнуюБазуДанныхToolStripMenuItem";
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem.Text = "Открыть стандартную базу данных";
            this.открытьСтандартнуюБазуДанныхToolStripMenuItem.Click += new System.EventHandler(this.открытьСтандартнуюБазуДанныхToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(750, 447);
            this.Controls.Add(this.panelOne);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.panelLP);
            this.Controls.Add(this.btnOkClose);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.lbPanelError);
            this.Controls.Add(this.panelInstructions);
            this.Controls.Add(this.panelCost);
            this.Controls.Add(this.panelClients);
            this.Controls.Add(this.lbError3);
            this.Controls.Add(this.lbError2);
            this.Controls.Add(this.lbError);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.panelRegistr);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.btnCost);
            this.Controls.Add(this.btnSchedule);
            this.Controls.Add(this.btnClients);
            this.Controls.Add(this.panelSchedule);
            this.Controls.Add(this.btnInstructions);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Спорт Комплекс";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.panelRegistr.ResumeLayout(false);
            this.panelRegistr.PerformLayout();
            this.panelClients.ResumeLayout(false);
            this.panelClients.PerformLayout();
            this.panelSchedule.ResumeLayout(false);
            this.panelSchedule.PerformLayout();
            this.panelInstructions.ResumeLayout(false);
            this.panelInstructions.PerformLayout();
            this.panelCost.ResumeLayout(false);
            this.panelCost.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelLP.ResumeLayout(false);
            this.panelLP.PerformLayout();
            this.panelOne.ResumeLayout(false);
            this.panelOne.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnInstructions;
        private System.Windows.Forms.Button btnClients;
        private System.Windows.Forms.Button btnSchedule;
        private System.Windows.Forms.Button btnCost;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel panelRegistr;
        private System.Windows.Forms.Label lbPass;
        private System.Windows.Forms.Label lbLogin;
        private System.Windows.Forms.TextBox tbPass;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Label lbError;
        private System.Windows.Forms.Label lbError2;
        private System.Windows.Forms.Label lbError3;
        private System.Windows.Forms.Panel panelClients;
        private System.Windows.Forms.Label lbICAddress;
        private System.Windows.Forms.Label lbICMobile;
        private System.Windows.Forms.Label lbICDate;
        private System.Windows.Forms.Label lbICPat;
        private System.Windows.Forms.Label lbICName;
        private System.Windows.Forms.Label lbICSurname;
        private System.Windows.Forms.TextBox tbICAddress;
        private System.Windows.Forms.TextBox tbICMobile;
        private System.Windows.Forms.TextBox tbICDate;
        private System.Windows.Forms.TextBox tbICPat;
        private System.Windows.Forms.TextBox tbICName;
        private System.Windows.Forms.TextBox tbICSurname;
        private System.Windows.Forms.Button btnICOk;
        private System.Windows.Forms.Panel panelSchedule;
        private System.Windows.Forms.Button btnISOk;
        private System.Windows.Forms.Label lbISTimeFinish;
        private System.Windows.Forms.Label lbISTimeStart;
        private System.Windows.Forms.Label lbISDate;
        private System.Windows.Forms.Label lbISId;
        private System.Windows.Forms.TextBox tbISFinish;
        private System.Windows.Forms.TextBox tbISTimeStart;
        private System.Windows.Forms.TextBox tbISDate;
        private System.Windows.Forms.TextBox tbISId;
        private System.Windows.Forms.Panel panelCost;
        private System.Windows.Forms.Button btnICostOk;
        private System.Windows.Forms.Button btnICostClose;
        private System.Windows.Forms.Label lbICostCount;
        private System.Windows.Forms.Label lbICostCost;
        private System.Windows.Forms.Label lbICostName;
        private System.Windows.Forms.TextBox tpICostCount;
        private System.Windows.Forms.TextBox tpICostCost;
        private System.Windows.Forms.TextBox tpICostName;
        private System.Windows.Forms.Button btnICClose;
        private System.Windows.Forms.Button btnISClose;
        private System.Windows.Forms.Panel panelInstructions;
        private System.Windows.Forms.Button btnIIClose;
        private System.Windows.Forms.Button btnIIOk;
        private System.Windows.Forms.Label lbIIPat;
        private System.Windows.Forms.Label lbIIName;
        private System.Windows.Forms.Label lbIISurname;
        private System.Windows.Forms.TextBox tbIIPat;
        private System.Windows.Forms.TextBox tbIIName;
        private System.Windows.Forms.TextBox tbIISurname;
        private System.Windows.Forms.Label lbPanelError;
        private System.Windows.Forms.Label lbCId;
        private System.Windows.Forms.TextBox tbCId;
        private System.Windows.Forms.Label lbSId;
        private System.Windows.Forms.Label lbIId;
        private System.Windows.Forms.TextBox tbIId;
        private System.Windows.Forms.TextBox tbSId;
        private System.Windows.Forms.Label lbCostId;
        private System.Windows.Forms.TextBox tbCostId;
        private System.Windows.Forms.Button btnOkClose;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem настройкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сменитьПарольToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.Panel panelLP;
        private System.Windows.Forms.Label lbLPError;
        private System.Windows.Forms.Button btnLPOk;
        private System.Windows.Forms.Label lbNewPass;
        private System.Windows.Forms.Label lbNewLogin;
        private System.Windows.Forms.Label lbOldPass;
        private System.Windows.Forms.Label lbOldLogin;
        private System.Windows.Forms.TextBox tbNewPass;
        private System.Windows.Forms.TextBox tbNewLogin;
        private System.Windows.Forms.TextBox tbOldPass;
        private System.Windows.Forms.TextBox tbOldLogin;
        private System.Windows.Forms.Button btnLPClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem расположениеToolStripMenuItem;
        private System.Windows.Forms.Panel panelOne;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem открытьСтандартнуюБазуДанныхToolStripMenuItem;
    }
}

